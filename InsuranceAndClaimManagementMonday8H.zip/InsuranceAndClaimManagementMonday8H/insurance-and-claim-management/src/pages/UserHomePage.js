import React, { useEffect } from 'react'
import UserNav from '../components/UserNav'

const UserHomePage = () => {
    
    
  return (
    <div>
        <UserNav/>
        
    </div>
  )
}

export default UserHomePage